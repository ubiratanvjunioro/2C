// IMPORTAR OS MODULOS NECESSARIOS 
const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');

//CRIAR UMA INSTANCIA DO EXPRESS

const app = express();

//CONFIGURAR O BODY_PARSER PARA 
// INTERPRETAR OS DADOS DOS FORMULARIO

app.use(bodyParser.urlencoded({extended: true}));

//SERVE ARQUIVOS ESTATICOS (HTML,CSS,JS)DA PASTA PUBLIC
app.use(express.static('public'));

//ROTA PARA LIDAR COM OS ENVIOS DO FORMULARIO

app.post('/enviar', (req,res)=>{
    const {nome, email} = req.body;//RECEBER OS DADOS DO FORMULARIO

    //CRIAR UMA STRING COM OS DADOS RECEBIDOS

    const dados= `Nome: ${nome}\nEmail: ${email}`;

    //ESCREVER OS DADOS NO ARQUIVO "DADOS.TXT"
    fs.appendFile('dados.txt', dados,(err)=>{
        if(err) {
            return res.send('Erro ao salvar os dados');
            }
            res.send('Dados salvos com sucesso');
    });

});

//INICIAR O SERVIDOR NA PORTA 3000

app.listen(3000,()=>{
    console.log('Servidor rodando na porta http://localhost:3000')
});
